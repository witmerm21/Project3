clear
file_path = '20.xlsx';

cell_data = readcell(file_path, 'Range', 'A:F');

actual_labels_cell = cell_data(:, 6); 
predicted_scores_cell = cell_data(:, 5);

actual_labels = strcmpi(actual_labels_cell, 'Positive');

predicted_scores = cell2mat(predicted_scores_cell);


[X,Y,T,AUC] = perfcurve(actual_labels, predicted_scores, true);

plot(X, Y)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC Curve')
legend(['AUC = ', num2str(AUC)])

desired_fpr = 0.1;
idx = find(X >= desired_fpr, 1, 'first');
threshold_at_desired_fpr = T(idx);

disp(['Threshold at desired FPR of ', num2str(desired_fpr), ': ', num2str(threshold_at_desired_fpr)]);
disp(['AUC ', num2str(AUC)]);